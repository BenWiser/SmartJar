package smartJar;

public class SharedVariables {
	public static final int WIDTH, HEIGHT;
	
	static {
		WIDTH = 1000;
		HEIGHT = 800;
	}
}
